<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>Submit Tutorial, Articles and White Papers</title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta name="Description" content="Submit Tutorial, Articles and White Papers - You can submit your White Papers Articles Tutorials Presentations"/>
<meta name="Keywords" content="Submit, White Papers, Articles, Tutorials, Presentations" />
<script language="javascript">
function ValidatePost()
{
	if( document.MainForm.first_name.value == "" )
	{
		alert( "Please enter your first name..." )
		document.MainForm.first_name.focus() ;
		return false ;
	}
	if( document.MainForm.emailid.value == "" )
	{
		alert( "Enter either e-mail ID..." )
		document.MainForm.emailid.focus() ;
		return false ;
	}
	if( document.MainForm.title.value == "" )
	{
		alert( "Please enter a short title of the document..." )
		document.MainForm.title.focus() ;
		return false ;
	}
	if( document.MainForm.file.value == "" )
	{
		alert( "Please attach a document..." )
		document.MainForm.file.focus() ;
		return false ;
	}
	if( document.MainForm.security.value == "" )
	{
		alert( "Please attach secuirty code..." )
		document.MainForm.security.focus() ;
		return false ;
	}
	if( document.MainForm.security.value != "BIG BOSS" )
	{
		alert( "Please attach correct secuirty code..." )
		document.MainForm.security.focus() ;
		return false ;
	}
	if( document.MainForm.message.value.length < 100 )
	{
		alert( "Enter a short description ... minimum 100 characters" )
		document.MainForm.message.focus() ;
		return false ;
	}
	return true;
}
</script>
<meta name="Keywords" content="Shared, tutorial, community, internet" />
<link rel="stylesheet" type="text/css" href="/scripts/shared.css" />
<div role="main" class="main">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<!-- PRINTING STARTS HERE -->
<div class="row">
<div class="content">
<div class="col-md-7 middle-col">
<h1>Submit Shared Tutorials, Articles and White Papers</h1>
<div class="center">
<small>Tutorials, Articles and White Papers Shared by the Internet Community</small>
</div>
<div class="clearer"></div>
<div class="topgooglead">
<hr />
<div style="padding-bottom:5px;padding-left:10px;">Advertisements</div>
<script type="text/javascript"><!--
google_ad_client = "pub-7133395778201029";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "image";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js"> 
</script>
</div>
<hr />
<br />
<!-- PRINTING STARTS HERE -->
<hr />
<p>Using this section you can share your knowledge in the following form:</p>
<ul>
<li><p>A Tutorial</p></li>
<li><p>An Article</p></li>
<li><p>A Presentation</p></li>
<li><p>A White Paper</p></li>
<li><p>Other written stuff</p></li>
</ul>
<p>To submit any of the above documents, fill out the form below and attach your document in any format. We will compile your document in our format and will upload on tutorialspoint.com with your name and other information you provide.</p>
<p><i>By submitting any of the above documents , the poster warrants that the document does not infringe the intellectual property rights of any third party and/or that the paper only uses third-party work pursuant to proper license.</i></p>
<hr />
<form name="MainForm" method="post" enctype="multipart/form-data" action="add-white-paper.php">
<table width="100%" border="0" cellspacing="2" cellpadding="2" >
<tr>
<td colspan="2" width="100%" bgcolor="#f1f1f1" height="10">&nbsp;<b><b>NOTE:</b> Fields marked with <span style="color:red;">*</span> are mandatory:</td>
</tr>
</table>
<br />
<table width="100%" border="0" cellspacing="2" cellpadding="2" >
<tr>
<tr>
<td><span style="color:red;">*</span>Submitted By:</td>
<td><input type="Text" maxlength="30" name="first_name" value="" size="30"></td>
</tr>
<tr>
<td><span style="color:red;">*</span>E-mail</td>

<td><input type="Text" maxlength="156" name="emailid" value="" size="30"></td>
</tr>
<tr>
<td>Phone</td>
<td><input type="Text" maxlength="20" name="phone" value="" size="30"></td>
</tr>
<tr>
<td>Company</td>
<td><input type="Text" maxlength="30" name="company_name" value="" size="30"></td>
</tr>
<tr>
<td><span style="color:red;">*</span>Document Title</td>
<td><input type="Text" name="title" maxlength="60" value="" size="30"></td>

</tr>
<tr>
<td><span style="color:red;">*</span>Attach Document</td>
<td><input type="file" name="file" size="17"></td>
</tr>
<tr>
<td><span style="color:red;">*</span>Security Code</td>
<td><input type="security" name="security" size="17"> ( Type: <b>BIG BOSS</b> )</td>
</tr>
<tr>
<td colspan="2" width="100%" bgcolor="#f1f1f1" height="10">&nbsp;<span style="color:red;">*</span><b>Short Description of Whitepaper:</b>&nbsp;
</td>
</tr>
<tr>
<td colspan="2" align="left" height="84" width="100%"> 
<textarea id="message" name="message" rows="15" scrolling="no" cols="72"></textarea>
</td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Submit " onClick="return ValidatePost();"> &nbsp;&nbsp;<input type=button name="return true;" value="Cancel" onclick='window.open("http://www.tutorialspoint.com", "_parent");'
</td>
</tr>
</table>
</form>
<br>
<div class="clearer"></div>
<hr>
<!-- PRINTING ENDS HERE -->
