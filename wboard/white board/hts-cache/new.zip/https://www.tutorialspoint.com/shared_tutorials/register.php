<!doctype html> 
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]> <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]> <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->
<head>
<meta charset="utf-8">
<title>Shared Tutorials and Articles</title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta name="description" content="Technical and managerial tutorials shared by internet community. You can submit your tutorial to promote it." />
<meta name="Keywords" content="Shared, tutorial, community, internet" />
<link rel="stylesheet" type="text/css" href="/scripts/shared.css" />
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script src="https://www.google-analytics.com/urchin.js" type="text/javascript"></script>
<script type="text/javascript">
   _uacct = "UA-232293-6";
   urchinTracker();
</script>
<!-- COMMON JAVA Script Ends -->
<script type="text/javascript" language="javascript">
<!--
function checkInput(string)
{
        var Chars = "/\?&=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-$.!@#%(){}[]:;+=_, ";
        for (var i = 0; i < string.length; i++)
        {
            if (Chars.indexOf(string.charAt(i)) == -1){
                return false ;
            }
        }
        return true ;
}
function checkID(string)
{
        var Chars = "/\?&=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-$.!@#%(){}[]:;+=_,";
        for (var i = 0; i < string.length; i++)
        {
            if (Chars.indexOf(string.charAt(i)) == -1){
                return false ;
            }
        }
        return true ;
}
function SubmitForm()
{
        if( document.MainForm.userid.value == "" )
        {
                alert( "Please enter a unique User ID..." )
                document.MainForm.userid.focus() ;
                return false ;
        }
        if( !checkID(document.MainForm.userid.value) )
        {
                alert( "Remove special charcters from User ID..." )
                document.MainForm.userid.focus() ;
                return false ;
        }
        if( document.MainForm.emailid.value == "" )
        {
                alert( "Please enter a correct email ID..." )
                document.MainForm.emailid.focus() ;
                return false ;
        }
        if( !checkInput(document.MainForm.emailid.value) )
        {
                alert( "Email address can not have junk characters..." )
                document.MainForm.emailid.focus() ;
                return false ;
        }
        if( document.MainForm.name.value == "" )
        {
                alert( "Please enter your real name..." )
                document.MainForm.name.focus() ;
                return false ;
        }
        return true ;
}
-->
</script>
<div role="main" class="main">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<!-- PRINTING STARTS HERE -->
<div class="row">
<div class="content">
<div class="col-md-7 middle-col">
<h1>Shared Tutorials</h1>
<div class="center">
<small>Tutorials Shared by the Internet Community</small>
</div>
<div class="clearer"></div>
<div class="topgooglead">
<hr />
<div style="padding-bottom:5px;padding-left:10px;">Advertisements</div>
<script type="text/javascript"><!--
google_ad_client = "pub-7133395778201029";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "image";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<br />

<form name="MainForm" method="post" target="_self" action="/register.php">
<fieldset class="shared">
<legend style="color:black; text-align:center;"><strong>Enter Registration Details:</strong></legend>
<br /><br />
<table border="0"  cellpadding="5" cellspacing="5" width="100%">
<tr>
<td colspan="2" width="100%" align="left">&nbsp;<b>NOTE : </b>Fields marked with <strong><span style="font:110%;color:red;">*</span></strong> are mandatory</td> </tr>
<tr>
<td style="text-align:right;" >&nbsp;<strong><span style="font:110%;color:red;">*</span></strong>User ID :</td>
<td style="text-align:left;">&nbsp;<input type="text" id="userid" name="userid" value="" style="width:296px;border:1px solid #aaa;" maxlength="20" /></td>
</tr>
<tr>
<td style="text-align:right;">&nbsp;<strong><span style="font-size:110%;color:red;">*</span></strong>Email ID :</td>
<td style="text-align:left;">&nbsp;<input type="text" id="emailid" name="emailid" value="" style="width:296px;border:1px solid #aaa;"  maxlength="60" />
</td>
</tr>
<tr>
<td style="text-align:right;">&nbsp;<strong><span style="font-size:110%;color:red;">*</span></strong>Real Name :</td>
<td style="text-align:left;">&nbsp;<input type="text" id="name" name="name" value="" style="width:296px;border:1px solid #aaa;" maxlength="60" />
</td>
</tr>
<tr>
<td style="text-align:right;">&nbsp;Homepage (http://) :</td>
<td style="text-align:left;">&nbsp;<input type="text" id="home_page" name="home_page" value="" style="width:296px;border:1px solid #aaa;" maxlength="150" />
</td>
</tr>
<tr>
<td style="text-align:right;">&nbsp;Location :</td>
<td style="text-align:left;">&nbsp;<input type="text" id="location" name="location" value="" style="width:296px;border:1px solid #aaa;" maxlength="60" />
</td>
</tr>
<tr>
<td style="text-align:right;"><strong><span style="font:110%;color:red;">*</span></strong>It proves that :</td>
<td style="text-align:left;">&nbsp;<div class="g-recaptcha" data-sitekey="6LdN1Q8UAAAAAL2hooUYE9Rl-s1nrW9aFN35N5dv"></div>
</td>
</tr>
<tr>
<td colspan="2" style="text-align:center;">
<br />
<br />
<input style="width:80px;" type="submit" name="Submit" value="Register" onclick="return SubmitForm();" />&nbsp;&nbsp;<input type="button" name="return NotSubmit();" style="width:80px;" value="Cancel" onclick='window.open("https://www.tutorialspoint.com/shared-tutorials.php", "_parent");' />
</td>
</tr>
<tr>
<td style="text-align:left;font-size:90%" colspan="2" >
<br /><br />
<p><b>**</b> If you have forgotten your password, we can <a href="/sendpwd.php">email it to you.</a></p>
</td>
</tr>
</table>
</fieldset>
</form>
<br/>
<div class="clearer"></div>
<hr>
<!-- PRINTING ENDS HERE -->
