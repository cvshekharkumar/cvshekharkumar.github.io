<!doctype html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]> <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]> <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--><html lang="en"><!--<![endif]-->
<head>
<meta charset="utf-8">
<title>Login - Shared Tutorials and Articles</title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta name="description" content="Login - Technical and managerial tutorials shared by internet community. You can submit your tutorial to promote it." />
<meta name="Keywords" content="Shared, tutorial, community, internet" />
<!-- COMMON JAVA Script Ends -->
<script type="text/javascript" language="javascript">
<!--
function checkInput(string)
{
        var Chars = "/\?&=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-$.!@#%(){}[]:;+=_, ";
        for (var i = 0; i < string.length; i++)
        {
            if (Chars.indexOf(string.charAt(i)) == -1){
                return false ;
            }
        }
        return true ;
}
function checkID(string)
{
        var Chars = "/\?&=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-$.!@#%(){}[]:;+=_,";
        for (var i = 0; i < string.length; i++)
        {
            if (Chars.indexOf(string.charAt(i)) == -1){
                return false ;
            }
        }
        return true ;
}
function SubmitForm()
{
        if( document.MainForm.userid.value == "" )
        {
                alert( "Please enter a unique User ID..." )
                document.MainForm.userid.focus() ;
                return false ;
        }
        if( !checkID(document.MainForm.userid.value) )
        {
                alert( "Remove special charcters from User ID..." )
                document.MainForm.userid.focus() ;
                return false ;
        }
        if( document.MainForm.password.value == "" )
        {
                alert( "Please enter a password..." )
                document.MainForm.password.focus() ;
                return false ;
        }
        return true ;
}
-->
</script>
<link rel="stylesheet" type="text/css" href="/scripts/shared.css" />
<div role="main" class="main">
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<!-- PRINTING STARTS HERE -->
<div class="row">
<div class="content">
<div class="col-md-7 middle-col">
<h1>Shared Tutorials</h1>
<div class="center">
<small>Tutorials Shared by the Internet Community</small>
</div>
<div class="clearer"></div>
<div class="topgooglead">
<hr />
<div style="padding-bottom:5px;padding-left:10px;">Advertisements</div>
<script type="text/javascript"><!--
google_ad_client = "pub-7133395778201029";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "image";
google_ad_channel = "";
//--></script>
<script type="text/javascript"
src="https://pagead2.googlesyndication.com/pagead/show_ads.js"> 
</script>
</div>

<form name="MainForm" method="post" target="_self" action="/login.php">
<fieldset  class="shared">
<legend><h1>Enter Login Detail</h1></legend>
<br /><br />
<table border="0"  cellpadding="5" cellspacing="5" width="100%">
<tr>
<td style="text-align:right;" >&nbsp;User ID :</td>
<td style="text-align:left;">&nbsp;<input type="text" id="userid" name="userid" style="width:200px;border:1px solid #aaa;" maxlength="20" /></td>
</tr>
<tr>
<td style="text-align:right;">&nbsp;Password :</td>
<td style="text-align:left;">&nbsp;<input type="password" id="password" name="password" style="width:200px;border:1px solid #aaa;"  maxlength="20" /></td>
</tr>
<tr>
<td colspan="2" style="text-align:center;">
<br />
<br />
<input type="submit" style="width:80px;" name="Submit" value="Login" onclick="return SubmitForm();" />&nbsp;&nbsp;<input type="button" style="width:80px;" name="return false;" value="Cancel" onclick='window.open("http://www.tutorialspoint.com", "_parent");' />
<br />
</td>
</tr>
<tr>
<td style="text-align:left;font-size:90%" colspan="2" >
<br /><br />
<p><b>**</b> If you are not registered with us then <a href="/register.php">Register Now</a></p>
<p><b>**</b> If you have forgotten your password, we can <a href="/sendpwd.php">email it to you.</a></p>
</td>
</tr>
</table>
</fieldset>
</form>
<br>
<div class="clearer"></div>
<!-- PRINTING ENDS HERE -->
