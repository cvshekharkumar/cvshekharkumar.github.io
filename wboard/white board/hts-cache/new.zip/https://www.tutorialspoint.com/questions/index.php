<!DOCTYPE html>
<html lang="en-US">
<head>
<title>The Best Technical Questions And Answers </title>
<meta charset="utf-8">
<meta name="description" content="The best text and video tutorials to provide simple and easy learning of various technical and non-technical subjects with suitable examples and code snippets."/>
<meta name="keywords" content="C, C++, Python, Java, HTML, CSS, JavaScript, SQL, PHP, jQuery, XML, DOM, Bootstrap, Tutorials, Articles, Programming, training, learning, quiz, preferences, examples, code"/>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes">
<link rel="stylesheet" href="/themes/css/style-min-v1.css?v=3.1.2.335">
<script src="/themes/js/script-min-v1.js?v=3.0.2040221"></script>
<script>function printPage() { window.print(); }</script>
<script id="vi1" type="text/javascript" src="//services.bilsyndication.com/adv1/?q=0a8a90220201327770f6c986bea026a3" defer="" async=""></script>
<script id="vi2">
var vitag = vitag || {};
vitag.outStreamConfig = { enablePC:false, enableMobile:false};
vitag.smartBannerConfig = { enablePC: false, enableMobile: true, disableHorizontalPosition: "right left middle", disableVerticalPosition: "top middle" };
</script>
<script id="adp" data-cfasync="false" type="text/javascript">(function(w, d) { var s = d.createElement('script'); s.src = '//delivery.adrecover.com/18107/adRecover.js'; s.type = 'text/javascript'; s.async = true; (d.getElementsByTagName('head')[0] || d.getElementsByTagName('body')[0]).appendChild(s); })(window, document);</script>
<link rel="stylesheet" href="/themes/css/style-qa.css">
<style>
.right-menu .mui-btn {
    background-color:#b82051;
}
a.demo {
    background:#b82051;
}
li.heading {
    background:#b82051;
}
.course-box{background:#b82051}
.home-intro-sub p{color:#b82051}
</style>
</head>
<body>
<header id="header">
<!-- pop-up -->
<div class="pop-modal overlay-pop popdiv">
<div class="modal-window small">
<span class="close" title="close">×</span>
<div class="pop-content">
</div>
<span class="msg" ></span>
</div>
</div>
<div class="wrap_loader">
<div class="imgLoader"><img src="/videotutorials/images/loader.gif" alt="Tutorialspoint" width="70" height="70"></div>
</div>
<input type="hidden" id="vu" name="vu" value="" />
<!-- pop-up -->
<!-- Top sub-menu Starts Here -->
<div class="mui-appbar mui-container-fulid top-menu">
<div class="mui-container">
<div class="top-menu-item home">
<a href="https://www.tutorialspoint.com/index.htm" target="_blank" title="TutorialsPoint - Home"><i class="fal fa-home"></i> <span>Home</span></a>
</div>
<div class="top-menu-item qa">
<a href="https://www.tutorialspoint.com/about/about_careers.htm" target="_blank" title="Job @ Tutorials Point"><i class="fa fa-suitcase"></i> <span>Jobs</span></a>
</div>
<div class="top-menu-item tools">
<a href="https://www.tutorialspoint.com/online_dev_tools.htm" target="_blank" title="Tools - Online Development and Testing Tools"><i class="fal fa-cogs"></i> <span>Tools</span></a>
</div>
<div class="top-menu-item coding-ground">
<a href="https://www.tutorialspoint.com/codingground.htm" target="_blank" title="Coding Ground - Free Online IDE and Terminal"><i class="fal fa-code"></i> <span>Coding Ground </span></a> 
</div>
<div class="top-menu-item current-affairs">
<a href="https://www.tutorialspoint.com/current_affairs.htm" target="_blank" title="Daily Current Affairs"><i class="fal fa-layer-plus"></i> <span>Current Affairs</span></a>
</div>
<div class="top-menu-item upsc-notes">
<a href="https://www.tutorialspoint.com/upsc_ias_exams.htm" target="_blank" title="UPSC IAS Exams Notes - TutorialsPoint"><i class="fal fa-user-tie"></i> <span>UPSC Notes</span></a>
</div>      
<div class="top-menu-item articles">
<a href="https://www.tutorialspoint.com/tutor_connect/index.php" target="_blank" title="Top Online Tutors - Tutor Connect"><i class="fal fa-user"></i> <span>Online Tutors</span></a>
</div>
<div class="top-menu-item whiteboard">
<a href="https://www.tutorialspoint.com/whiteboard.htm" target="_blank" title="Free Online Whiteboard"><i class="fal fa-chalkboard"></i> <span>Whiteboard</span></a>
</div>
<div class="top-menu-item net-meeting">
<a href="https://www.tutorialspoint.com/netmeeting.php" target="_blank" title="A free tool for online video conferencing"><i class="fal fa-chalkboard-teacher"></i> <span>Net Meeting</span></a> 
</div>
<div class="top-menu-item articles">
<a href="https://www.tutorix.com" target="_blank" title="Tutorx - The Best Learning App" rel="nofollow"><i class="fal fa-video"></i> <span>Tutorix</span></a> 
</div>        
<div class="top-menu-item qa login">
<a href="/videotutorials/login.php" target="_blank" title="Tutorials Point - Login"><i class="fa fa-sign-in-alt"></i> <span>Login</span></a> 
</div>        
<div class="top-menu-item qa login">
<a href="/videotutorials/subscription.php" target="_blank" title="Premium Subscription"><i class="fa fa-book-reader"></i> <span>Premium</span></a> 
</div>        
<div class="social-menu-item">
<a href="https://www.facebook.com/tutorialspointindia" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint @ Facebook"><i class="fab fa-facebook-f"></i></a> 
<a href="https://www.twitter.com/tutorialspoint" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint @ Twitter"><i class="fab fa-twitter"></i></a>
<a href="https://www.linkedin.com/company/tutorialspoint" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint @ Linkedin"><i class="fab fa-linkedin-in"></i></a>
<a href="https://www.youtube.com/channel/UCVLbzhxVTiTLiVKeGV7WEBg" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint YouTube"><i class="fab fa-youtube"></i></a>
</div>        
</div>
</div>
<!-- Top sub-menu Ends Here -->
<!-- Top main-menu Starts Here -->
<div class="mui-appbar mui-container-fulid mui--appbar-line-height mui--z1" id="logo-menu">
<div class="mui-container">
<div class="left-menu">
<a href="https://www.tutorialspoint.com/index.htm" title="Tutorialspoint">
<img class="tp-logo" alt="tutorialspoint" src="/3d_figures_and_volumes/images/logo.png">
</a>
<div class="mui-dropdown">
<a class="mui-btn mui-btn--primary categories" data-mui-toggle="dropdown"><i class="fa fa-th-large"></i> 
<span>Categories <span class="mui-caret"></span></span></a>            
<ul class="mui-dropdown__menu cat-menu">
<li>
<ul>
<li><a href="/questions/category/java8"><i class="fa fa-caret-right"></i> Java</a></li>
<li><a href="/questions/category/jsp"><i class="fa fa-caret-right"></i> JSP</a></li>
<li><a href="/questions/category/ios"><i class="fa fa-caret-right"></i> iOS</a></li>
<li><a href="/questions/category/html"><i class="fa fa-caret-right"></i> HTML</a></li>
<li><a href="/questions/category/android"><i class="fa fa-caret-right"></i> Android</a></li>
<li><a href="/questions/category/python"><i class="fa fa-caret-right"></i> Python</a></li>
<li><a href="/questions/category/c"><i class="fa fa-caret-right"></i> C Programming</a></li>
<li><a href="/questions/category/cplusplus"><i class="fa fa-caret-right"></i> C++ Programming</a></li>
<li><a href="/questions/category/csharp"><i class="fa fa-caret-right"></i> C#</a></li>
<li><a href="/questions/category/php"><i class="fa fa-caret-right"></i> PHP</a></li>
<li><a href="/questions/category/css"><i class="fa fa-caret-right"></i> CSS</a></li>
<li><a href="/questions/category/javascript"><i class="fa fa-caret-right"></i> Javascript</a></li>
<li><a href="/questions/category/jquery"><i class="fa fa-caret-right"></i> jQuery</a></li>
<li><a href="/questions/category/sap"><i class="fa fa-caret-right"></i> SAP</a></li>
<li><a href="/questions/category/sap-hana"><i class="fa fa-caret-right"></i> SAP HANA</a></li>
<li><a href="/questions/category/data-structure"><i class="fa fa-caret-right"></i> Data Structure</a></li>
<li><a href="/questions/category/rdbms"><i class="fa fa-caret-right"></i> RDBMS</a></li>
<li><a href="/questions/category/mysql"><i class="fa fa-caret-right"></i> MySQL</a></li>
<li><a href="/questions/category/mathematics"><i class="fa fa-caret-right"></i> Mathematics</a></li>
<li><a href="/questions/category/8085"><i class="fa fa-caret-right"></i> 8085 Microprocessor</a></li>
<li><a href="/questions/category/operating-system"><i class="fa fa-caret-right"></i> Operating System</a></li>
<li><a href="/questions/category/digital-electronics"><i class="fa fa-caret-right"></i> Digital Electronics</a></li>
<li><a href="/questions/category/analysis-of-algorithms"><i class="fa fa-caret-right"></i> Analysis of Algorithms</a></li>
<li><a href="/questions/category/mobile-development"><i class="fa fa-caret-right"></i> Mobile Development</a></li>
<li><a href="/questions/category/front-end-technology"><i class="fa fa-caret-right"></i> Front End </a></li>
<li><a href="/questions/category/web-development"><i class="fa fa-caret-right"></i> Web Development</a></li>
<li><a href="/questions/category/selenium"><i class="fa fa-caret-right"></i> Selenium</a></li>
<li><a href="/questions/category/mongodb"><i class="fa fa-caret-right"></i> MongoDB</a></li>
<li><a href="/questions/category/computer-network"><i class="fa fa-caret-right"></i> Computer Network</a></li>
<li><a href="/questions/category/general-topics"><i class="fa fa-caret-right"></i> General Topics</a></li>
</ul>
</li>
</ul>
<div class="clear"></div>
</div> 
</div>
<div class="right-menu">
<div class="toc-toggle">
<a href="javascript:void(0);"><i class="fa fa-bars"></i></a>
</div>
<div class="mobile-search-btn">
<a href="https://www.tutorialspoint.com/index.htm"><i class="fal fa-search"></i></a>
</div>
<div class="search-box">
<script async src="https://cse.google.com/cse.js?cx=000263362972888060243:yfed6eu421q"></script>
<div class='gcse-search'></div>
</div>
<div class="menu-btn library-btn">
<a href="https://www.tutorialspoint.com/tutorialslibrary.htm"><i class="fal fa-cubes"></i> <span>Library</span></a>
</div>
<div class="menu-btn videos-btn">
<a href="https://www.tutorialspoint.com/videotutorials/index.php"><i class="fal fa-video"></i> <span>Videos</span></a> 
</div>
<div class="menu-btn videos-btn">
<a href="https://www.tutorialspoint.com/questions/index.php"><i class="fa fa-location-arrow"></i> <span>Q/A</span></a>
</div>
<div class="menu-btn ebooks-btn">
<a href="https://store.tutorialspoint.com"><i class="fal fa-book"></i> <span>eBooks</span></a>
</div>
<div class="mui-dropdown">
<button class="mui-btn mui-btn--primary mobile-menu" data-mui-toggle="dropdown">
<span class="mui-caret"></span>
</button>
<ul class="mui-dropdown__menu">
<li class="login"><a href="https://www.tutorialspoint.com/videotutorials/login.php"><i class="fal fa-sign-in-alt"></i> <span>Login</span></a></li>
<li><a href="https://www.tutorialspoint.com/tutorialslibrary.htm"><i class="fal fa-cubes"></i> <span>Library</span></a></li>
<li><a href="https://www.tutorialspoint.com/videotutorials/index.php"><i class="fal fa-video"></i> <span>Videos</span></a></li>
<li><a href="https://store.tutorialspoint.com"><i class="fal fa-book"></i> <span>eBooks</span></a></li>
</ul>
</div>
</div>
</div>
</div>
<!-- Top main-menu Ends Here -->
</header>
<!--
<style>.qa_answer_widget img{width:40px!important;} img.cat-img{width:30px!important;} .mui-dropdown__menu{left:-130px!important;} .content{padding-top:125px!important;}</style>
-->
<div class="mui-container-fluid content">
<div class="mui-container">
<!-- Tutorial ToC Starts Here -->
<div class="mui-col-md-3 tutorial-toc">
<div class="mini-logo">
<img style="width: 162px;" src="/images/QAicon.png" alt="Technical Questions and Answers" />
</div>
<ul class="toc chapters trending">
<li class="heading big-font"><i class="fa fa-th-large"></i> Trending Categories</li>
<li><a href="/questions/category/data-structure"><img alt="Data Structure" src="/images/Data-Structure.png" class="cat-img" /> Data Structure</a></li>
<li><a href="/questions/category/computer-network"><img alt="Networking" src="/images/Networking.png" class="cat-img" /> Networking</a></li>
<li><a href="/questions/category/rdbms"><img alt="RDBMS" src="/images/dbms.png" class="cat-img" /> RDBMS</a></li>
<li><a href="/questions/category/operating-system"><img alt="Operating System" src="/images/Operating-System.png" class="cat-img" /> Operating System</a></li>
<li><a href="/questions/category/Java"><img alt="Java" src="/images/java8.png" class="cat-img" /> Java</a></li>
<li><a href="/questions/category/ios"><img alt="iOS" src="/images/ios.png" class="cat-img" /> iOS</a></li>
<li><a href="/questions/category/HTML"><img alt="HTML" src="/images/html.png" class="cat-img" /> HTML</a></li>
<li><a href="/questions/category/CSS"><img alt="CSS" src="/images/css.png" class="cat-img" /> CSS</a></li>
<li><a href="/questions/category/android"><img alt="Android" src="/images/Android.png" class="cat-img" /> Android</a></li>
<li><a href="/questions/category/python"><img alt="Python" src="/images/Python.png" class="cat-img" /> Python</a></li>
<li><a href="/questions/category/c"><img alt="C Programming" src="/images/C-programming.png" class="cat-img" /> C Programming</a></li>
<li><a href="/questions/category/cplusplus"><img alt="C++" src="/images/C-PLUS.png" class="cat-img" /> C++</a></li>
<li><a href="/questions/category/csharp"><img alt="C#" src="/images/C-hash.png" class="cat-img" /> C#</a></li>
<li><a href="/questions/category/mongodb"><img alt="MongoDB" src="/images/mongodb.png" class="cat-img" /> MongoDB</a></li>
<li><a href="/questions/category/mysql"><img alt="MySQL" src="/images/MySQL.png" class="cat-img" /> MySQL</a></li>
<li><a href="/questions/category/Javascript"><img alt="Javascript" src="/images/Javascript.png" class="cat-img" /> Javascript</a></li>
<li><a href="/questions/category/php"><img alt="PHP" src="/images/php.png" class="cat-img" /> PHP</a></li>
</ul>
<ul class="toc reading">
<li class="sreading">Selected Reading</li>
<li><a target="_top" href="/upsc_ias_exams.htm">UPSC IAS Exams Notes</a></li>
<li><a target="_top" href="/developers_best_practices/index.htm">Developer's Best Practices</a></li>
<li><a target="_top" href="/questions_and_answers.htm">Questions and Answers</a></li>
<li><a target="_top" href="/effective_resume_writing.htm">Effective Resume Writing</a></li>
<li><a target="_top" href="/hr_interview_questions/index.htm">HR Interview Questions</a></li>
<li><a target="_top" href="/computer_glossary.htm">Computer Glossary</a></li>
<li><a target="_top" href="/computer_whoiswho.htm">Who is Who</a></li>
</ul>
<div id="stickyparent">
<div style="height:250px;width:300px;" id="sticky-ad">
<div class="adsbyvli" data-ad-slot="vi_9012177"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_9012177")})</script>
</div>
</div>
</div>
<!-- Tutorial ToC Ends Here -->
<!-- Tutorial Content Starts Here -->
<div class="mui-col-md-6 tutorial-content qa-content">
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-find-duplicate-element-from-nplus1-numbers-ranging-from-1-to-n-in-python" target="_blank"> Program to find duplicate element from n+1 numbers ranging from 1 to n in Python</a>
</h2>                              

<div class="qa_category" id="tags_43904">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 11:00:46 </div>
<div class="clear"></div>
Suppose we have a list of numbers called nums of length n + 1. These numbers are picked from range 1, 2, ..., n. As we know, using the pigeonhole principle, there must be a duplicate. We have to find that and return it.So, if the input is like [2, ... <a href="https://www.tutorialspoint.com/program-to-find-duplicate-element-from-nplus1-numbers-ranging-from-1-to-n-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div style="text-align: center;">
<div id="vi_top_ads1" style="text-align:center !important;"></div>
   <script>
     (function() {
     var adPos = document.getElementById('vi_top_ads1');
     var ad_id_650 = "vi_9014435";
     var ad_id_300 = "vi_9017967";
     var width = window.innerWidth;
     var ad_id = ad_id_650;
     if( width <= 768 ){
        ad_id =  ad_id_300;
     }
     adPos.innerHTML = '<div class="adsbyvli" data-ad-slot="' + ad_id + '"></div>';
     (vitag.displayInit = window.vitag.displayInit || []).push(function () {
         viAPItag.display(ad_id);
     });
     }())
   </script>
</div>
</div>
</div><div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-find-all-words-which-share-same-first-letters-in-python" target="_blank"> Program to find all words which share same first letters in Python</a>
</h2>                              

<div class="qa_category" id="tags_43903">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:58:53 </div>
<div class="clear"></div>
Suppose we have a list of words in lowercase letters, we have to find the length of the longest contiguous sublist where all words have the same first letter.So, if the input is like [&quot;she&quot;, &quot;sells&quot;, &quot;seashells&quot;, &quot;on&quot;, &quot;the&quot;, &quot;seashore&quot;], then the output will be 3 as three contiguous words ... <a href="https://www.tutorialspoint.com/program-to-find-all-words-which-share-same-first-letters-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-check-programmers-convention-arrangements-are-correct-or-not-in-python" target="_blank"> Program to check programmers convention arrangements are correct or not in Python</a>
</h2>                              

<div class="qa_category" id="tags_43902">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:56:57 </div>
<div class="clear"></div>
Suppose we have a number n, this is representing programmers looking to enter a convention, and we also have a list of number, convention 1 represents a programmer and 0 represents empty space. Now the condition is no two programmers can sit next to each other, we have to check ... <a href="https://www.tutorialspoint.com/program-to-check-programmers-convention-arrangements-are-correct-or-not-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-find-the-formatted-amount-of-cents-of-given-amount-in-python" target="_blank"> Program to find the formatted amount of cents of given amount in Python</a>
</h2>                              

<div class="qa_category" id="tags_43901">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:55:19 </div>
<div class="clear"></div>
Suppose we have a positive number n, where n is representing the amount of cents we have, we have to find the formatted currency amount.So, if the input is like n = 123456, then the output will be &quot;1, 234.56&quot;.To solve this, we will follow these steps &minus;cents := n ... <a href="https://www.tutorialspoint.com/program-to-find-the-formatted-amount-of-cents-of-given-amount-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-check-whether-given-password-meets-criteria-or-not-in-python" target="_blank"> Program to check whether given password meets criteria or not in Python</a>
</h2>                              

<div class="qa_category" id="tags_43900">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:53:14 </div>
<div class="clear"></div>
Suppose we have a string s, representing a password, we have to check the password criteria. There are few rules, that we have to follow &minus;Password length will be At least 8 characters and at most 20 characters long.Password contains at least one digitPassword contains at least one lowercase character ... <a href="https://www.tutorialspoint.com/program-to-check-whether-given-password-meets-criteria-or-not-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-find-the-nth-row-of-pascal-s-triangle-in-python" target="_blank"> Program to find the nth row of Pascal&#039;s Triangle in Python</a>
</h2>                              

<div class="qa_category" id="tags_43899">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:50:47 </div>
<div class="clear"></div>
Suppose we have a number n, we have to find the nth (0-indexed) row of Pascal&#39;s triangle. As we know the Pascal&#39;s triangle can be created as follows &minus;In the top row, there is an array of 1.Subsequent row is made by adding the number above and to the left ... <a href="https://www.tutorialspoint.com/program-to-find-the-nth-row-of-pascal-s-triangle-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">
<div class="qa_widget">
<div style="text-align: center;">
<div id="vi_top_ads2" style="text-align:center !important;"></div>
   <script>
     (function() {
     var adPos = document.getElementById('vi_top_ads2');
     var ad_id_650 = "vi_9014435";
     var ad_id_300 = "vi_9017967";
     var width = window.innerWidth;
     var ad_id = ad_id_650;
     if( width <= 768 ){
        ad_id =  ad_id_300;
     }
     adPos.innerHTML = '<div class="adsbyvli" data-ad-slot="' + ad_id + '"></div>';
     (vitag.displayInit = window.vitag.displayInit || []).push(function () {
         viAPItag.display(ad_id);
     });
     }())
   </script>
</div>
</div>
</div><div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-find-maximum-number-of-balanced-groups-of-parentheses-in-python" target="_blank"> Program to find maximum number of balanced groups of parentheses in Python</a>
</h2>                              

<div class="qa_category" id="tags_43898">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:37:58 </div>
<div class="clear"></div>
Suppose we have a string s that contains balanced parentheses &quot;(&quot; and &quot;)&quot;, we have to split them into the maximum number of balanced groups.So, if the input is like &quot;(()())()(())&quot;, then the output will be [&#39;(()())&#39;, &#39;()&#39;, &#39;(())&#39;]To solve this, we will follow these steps &minus;temp := blank stringgroups ... <a href="https://www.tutorialspoint.com/program-to-find-maximum-number-of-balanced-groups-of-parentheses-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-check-given-string-is-pangram-or-not-in-python" target="_blank"> Program to check given string is pangram or not in Python</a>
</h2>                              

<div class="qa_category" id="tags_43897">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:36:21 </div>
<div class="clear"></div>
Suppose we have a string s, this is representing a sentence, we have to check whether every letter of the English alphabet is used at least once or not.So, if the input is like &quot;The grumpy wizards make toxic brew, for the evil queen and Jack&quot;, then the output will ... <a href="https://www.tutorialspoint.com/program-to-check-given-string-is-pangram-or-not-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-count-number-of-palindromes-of-size-k-can-be-formed-from-the-given-string-characters-in-python" target="_blank"> Program to count number of palindromes of size k can be formed from the given string characters in Python</a>
</h2>                              

<div class="qa_category" id="tags_43896">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:34:40 </div>
<div class="clear"></div>
Suppose we have a string s that is representing alphabet characters and a number k. We have to find the number of palindromes where we can construct of length k using only letters in s. And we can use these letters more than once if we want.So, if the input ... <a href="https://www.tutorialspoint.com/program-to-count-number-of-palindromes-of-size-k-can-be-formed-from-the-given-string-characters-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="question_section">                                 
<div class="qa_widget">                                
<div class="qa_post qa_list">
<h2>
<a href="https://www.tutorialspoint.com/program-to-count-number-of-valid-pairs-from-a-list-of-numbers-where-pair-sum-is-odd-in-python" target="_blank"> Program to count number of valid pairs from a list of numbers, where pair sum is odd in Python</a>
</h2>                              

<div class="qa_category" id="tags_43895">
<a href='https://www.tutorialspoint.com/questions/category/Python' target='_blank'><span>Python</span></a><a href='https://www.tutorialspoint.com/questions/category/Server-Side-Programming' target='_blank'><span>Server Side Programming</span></a><a href='https://www.tutorialspoint.com/questions/category/Programming' target='_blank'><span>Programming</span></a></div>
</div>   
<div class="qa_answer_widget">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty"><img src="https://www.tutorialspoint.com/assets/profiles/123881/profile/60_150126-1566966196.png" alt="Arnab Chakraborty"></a> 
<div class="qa_answer_detail">
<a href="https://www.tutorialspoint.com/answers/arnab-chakraborty-4" title="Arnab Chakraborty">Arnab Chakraborty</a>    
</div>
<div class="qa_answer_dtm">
Published on 06-Oct-2020 10:33:30 </div>
<div class="clear"></div>
Suppose we have a list of positive numbers nums, we have to find the number of valid pairs of indices (i, j), where i &lt; j, and nums[i] + nums[j] is an odd number.So, if the input is like [5, 4, 6], then the output will be 2, as two ... <a href="https://www.tutorialspoint.com/program-to-count-number-of-valid-pairs-from-a-list-of-numbers-where-pair-sum-is-odd-in-python"><span class="read_more">Read More</span></a></div>
</div> 
</div> 
<div class="clear"></div>
<div class="job-index qa_widget" style="padding:0px 10px 0px 10px!important; margin:0px!important;">
<div class="pages">
<a title="Go to page 1 of 4074" class="current number" href="https://www.tutorialspoint.com/questions/1">1</a> <a class="number" title="Go to page 2 of 4074" href="https://www.tutorialspoint.com/questions/2">2</a> <a class="number" title="Go to page 3 of 4074" href="https://www.tutorialspoint.com/questions/3">3</a> <a class="number" title="Go to page 4 of 4074" href="https://www.tutorialspoint.com/questions/4">4</a> <a class="number" title="Go to page 5 of 4074" href="https://www.tutorialspoint.com/questions/5">5</a> <a class="number" title="Go to page 6 of 4074" href="https://www.tutorialspoint.com/questions/6">6</a> <a class="number" title="Go to page 7 of 4074" href="https://www.tutorialspoint.com/questions/7">7</a>  ... <a class="number" title="Go to page 4074 of 4074" href="https://www.tutorialspoint.com/questions/4074">4074</a> <a  href="https://www.tutorialspoint.com/questions/2" title="Next Page">Next <i class='fa-arrow-right'></i></a>
</div>
</div>
<div class="google-bottom-ads" id="google-bottom-ads">
<div>Advertisements</div>
<div id="vi_bottom_ads"></div>
   <script>
     (function() {
     var adPos = document.getElementById('vi_bottom_ads');
     var mobile_ad_id = "vi_9017966";
     var desktop_ad_id = "vi_9013190";
     var ad_id = window.innerWidth <= 768 ? mobile_ad_id : desktop_ad_id;
     adPos.innerHTML = '<div class="adsbyvli" data-ad-slot="' + ad_id + '"></div>';
     (vitag.displayInit = window.vitag.displayInit || []).push(function () {
         viAPItag.display(ad_id);
     });
     }())
   </script>
<div class="space-bottom"></div>
</div>
</div>
<!-- Tutorial Content Ends Here -->
<div class="mui-col-md-2 google-right-ads" id="chapter-menu" style="display: none;">
<input type="hidden" id="vu" name="vu" value=""/>
<div class="space-top"></div>
<div class="mui-panel">
<ul class="paid-menu" id="div-right-menu">
<li><a class="hide-on-mobile" href="javascript:printPage();" title="Print this page"><i class="fa fa-print"></i> Print</a></li>
<li><a href="javascript:void(0)" class="add_notes" title="Add Custom Notes" onclick="add_notes();"><i class="fa fa-edit"></i>&nbsp;Add Notes</a></li>
<li><a href="javascript:void(0)" class="clsPage text-bookmark" id="text-bookmark" title="Add Bookmark" onclick="text_bookmark()"><i class="fal fa-bookmark"></i>&nbsp;Bookmark this page </a></li>
<li><a href="javascript:void(0);" id="report_error_popup" onclick="report_error_popup();" title="Report Error"><i class="fal fa-bell"></i>&nbsp;Report Error</a></li>
<li><a href="javascript:void(0);" id="suggestion_popup" title="Give Suggestions" onclick="suggestion_popup();"><i class="fal fa-badge-check"></i>&nbsp;Suggestions</a></li>
</ul>
<div class="profile-my-notes" id="text_notes_div" style="display:none;">
<textarea rows="10" class="text_notes" id="text_notes" name="text_notes" placeholder="Enter your custom notes..."></textarea>
<br>
<a href="javascript:void(0);" id="submit_text_notes" class="butn-save" onclick="submit_text_notes();"> Save</a>
<a href="javascript:void(0);" class="pop-no butn-cancel" onclick="notesClose();"> Close</a>
<p class="notes_msg"  ></p>
</div>
<div class="bottom-menu">
<button class="tp-btn"><i class="fal fa-box-up"></i> <a href="/videotutorials/dashboard.php">Dashboard</a></button>
<button class="tp-btn"><i class="fal fa-sign-out-alt"></i> <a href="/videotutorials/userlogout.php">Logout</a></button>
</div>
</div>
</div>
<div class="mui-col-md-2 google-right-ads" id="google-right-ads">
<div class="space-top"></div>
<div class="google-right-ad" style="margin: 0px auto !important;">
<div class="adsbyvli" data-ad-slot="vi_9017966"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_9017966")})</script>
</div>
<div class="google-right-ad" style="margin-top:16px">
<div class="adsbyvli" data-ad-slot="vi_9017967"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_9017967")})</script>
</div>
<div class="space-bottom"></div>
<div class="google-right-ad" style="margin-top:16px;margin-bottom:15px;">
<div class="adsbyvli" data-ad-slot="vi_9013289"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_9013289")})</script>
</div>
</div>
</div>
</div>
<!-- Right Column Ends Here -->
<div class="clear"></div>
<footer id="footer">
<div class="mui--text-center">
<div class="mui--text-caption mui--text-light">
<a href="/index.htm" class="logo"><img class="img-responsive" src="/images/logo-black.png" alt="Tutorials Point" title="Tutorials Point"></a>
</div>
<ul class="mui-list--inline mui--text-body2 mui--text-light">
<li><a href="/about/index.htm"><i class="fal fa-globe"></i> About us</a></li>
<li><a href="/about/about_terms_of_use.htm"><i class="fal fa-asterisk"></i> Terms of use</a></li>
<li><a href="/about/about_privacy.htm#cookies"> <i class="fal fa-shield-check"></i> Cookies Policy</a></li>
<li><a href="/about/faq.htm"><i class="fal fa-question-circle"></i> FAQ's</a></li>
<li><a href="/about/about_helping.htm"><i class="fal fa-hands-helping"></i> Helping</a></li>
<li><a href="/about/contact_us.htm"><i class="fal fa-map-marker-alt"></i> Contact</a></li>
</ul>
<div class="mui--text-caption mui--text-light bottom-copyright-text">&copy; Copyright 2020. All Rights Reserved.</div>
</div>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-232293-17"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'UA-232293-17');
</script>
<script src="https://www.tutorialspoint.com/videotutorials/js/text_menu.js?v=1"></script>
<script>
function readCookie(name) {
     var nameEQ = name + "=";
     var ca = document.cookie.split(';');
     for (var i = 0; i < ca.length; i++) {
          var c = ca[i];
          while (c.charAt(0) == ' ') c = c.substring(1, c.length);
          if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
     }
     return null;
}
$(document).ready(function (){
    var cval = readCookie('subscription_purchased');
    if(cval == '1'){
          // logged in and purchased subscription.
          $('#google-right-ads').remove();
          $('#vi1').remove();
          $('#vi2').remove();
          $('#vi_top_ads1').parent().parent().remove();
          $('#vi_top_ads2').parent().parent().remove();
          $('#adp').remove();
          $('#stickyparent').remove();
          $('#google-top-ads').remove();
          $('#vi_top_ads').remove();
          $('#google-bottom-ads').remove();
          $('.tutorial-content hr').remove();
          $('.login').remove();
          $('#chapter-menu').show();
          $('.content h1').css("border-bottom", "none");
          $('.google-right-ads').css("padding-right", "0px");
          $('.tutorial-content').css("border-radius", "10px");
          $('#chapter-menu .mui-panel').css("border-radius", "10px");
     }
});
</script>
</footer>
</body>
</html>
