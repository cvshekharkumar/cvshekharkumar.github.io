<!DOCTYPE html>  
<html>  
<head>  
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Net Meeting</title>
<meta name="Description" content="Net Meeting - A free high quality web conferencing tool to have audio, video chat online any time anywhere using laptop, desktop, mobile phone or tablets. Suitable for your business and personal usage."/>
<meta name="Keywords" content="Free, Net, Meeting, Web, Conferencing, Tool, audio, video, chat, mobile, desktop, laptop, tablets "/>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="themes/css/gray/easyui.css">
<link rel="stylesheet" type="text/css" href="themes/css/icon.css">
<script src="themes/js/jquery.min.js"></script>
<script src="themes/easyui/jquery.easyui.min.js"></script>
<script src='https://meet.jit.si/external_api.js'></script>
<style>
#south, #center {
    background-color: #ffffff;
    background-image: url(/images/brick-wall.png);
    overflow: hidden;
}
.imgLoader{
  visibility:visible;
}
.centered {
    position: absolute;
    text-align: center;
    width: 100%;
    height: 100%;
}
.centered .imgLoader{
    position: absolute;
    top: 50% !important;
    left: 50%;
}
.l-btn span .l-btn-icon-left {
    padding: 0px;
    background-position: left center;
}
#mainimg {
    position: relative;
    height: auto;
    width: 41%;
}
.meeting {
    height: 17px;
    color: #717171;
    font-size: 180%;
    float: left;
    margin: 9px 5px 0px 10px;
    padding: 8px 0px 0px 5px;
    text-transform: uppercase;
    font-weight: bold;
    letter-spacing: 1px;
    font-family: monospace;
}
</style>
</head>
<body class="easyui-layout" id="cc">
<!--HEADER STARTS -->
<div data-options="region:'north'" style="height:65px; width:100%;overflow:hidden;">
   <a href='http://www.tutorialspoint.com/'>
      <img src="/images/logo.png" height="50px" style="padding:5px; float:left;"/>
   </a>
  <h1 class="meeting"><span>|</span> Net Meeting</h1>
  <div style="margin:18px 0px 0px 0px;">
       <a href="http://www.tutorialspoint.com/netmeeting.php" class="easyui-linkbutton" data-options="iconCls:'icon-home-green', plain:true" style="font-size:12px;float:right; margin-right:5px; position:relative; top:-1px;" group=""><span class="l-btn-left l-btn-icon-left">Home</span></a>
  </div>
</div>
<!--STAGE STARTS -->
<div id="center" data-options="region:'center'" style="height:100%; width:100%">
<div class="centered">
   <div class="imgLoader">
      <img src="/images/loading.gif" alt="" width="70" height="70" />
      <div id="wait"></div>
   </div>
   <div id="stage">
   <img id="mainimg" src="/images/netmeeting.jpg" alt="Net Meeting"/>
    <div style="margin-top:15px; text-align:center;">
       <div style="margin-bottom:15px">
        <input id="room_id" class="easyui-textbox" data-options="prompt:'Enter Room ID...',iconCls:'icon-lock',iconWidth:38" style="passing:7px;width:303px;height:32px;"/>
       </div>
       <div style="margin-bottom:20px">
        <input id="user_name" class="easyui-textbox" data-options="prompt:'Enter Your Name...', iconCls:'icon-man',iconWidth:38" style="passing:7px;width:303px;height:32px;"/>
       </div>
        <a href="#" id="start" class="easyui-linkbutton" data-options="iconCls:'icon-start-meeting',size:'large',iconAlign:'top', width:'80px'"><b>Join Now</b></a>
    </div>
    </div>
</div>
</div>
<!--STAGE ENDS -->
<script>
$( document ).ready(function( event ) {
     $('#room_id').focus();
     $('#start').bind('click', function(){
        $(".imgLoader").css("visibility", "visible");
        var room_id = escape($("#room_id").val());
        if( room_id.length < 6 ){
            $.messager.alert('Room ID','Please enter atleast 6 characters');
            $('#room_id').focus();
            return false;
        }
        var user_name = escape($("#user_name").val());
        if( user_name.length < 4 ){
            $.messager.alert('User Name','Please enter atleast 4 characters');
            $('#user_name').focus();
            return false;
        }
        const domain = 'meet.tutorix.com';
        $("#center").html("");
        const options = {
            roomName: room_id,
            parentNode: document.querySelector('#center'),
            interfaceConfigOverwrite: {SHOW_JITSI_WATERMARK:false, JITSI_WATERMARK_LINK:false},
        };
        const api = new JitsiMeetExternalAPI(domain, options);
        api.executeCommand('displayName', user_name);
        setTimeout(function(){
          $(".imgLoader").css("visibility", "hidden");
        }, 5000);
    });
    $("#cc").css("visibility", "visible");
    $(".imgLoader").css("visibility", "hidden");
});
</script>
</body>
</html>
