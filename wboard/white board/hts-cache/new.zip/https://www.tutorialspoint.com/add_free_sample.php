
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Scala - Overview - Tutorialspoint</title>
<meta charset="utf-8">
<meta name="description" content="Scala - Overview - Scala, short for Scalable Language, is a hybrid functional programming language. It was created by Martin Odersky. Scala smoothly integrates the features of obj"/>
<meta name="keywords" content="C, C++, Python, Java, HTML, CSS, JavaScript, SQL, PHP, jQuery, XML, DOM, Bootstrap, Tutorials, Articles, Programming, training, learning, quiz, preferences, examples, code"/>
<link rel="canonical" href="https://www.tutorialspoint.com/scala/scala_overview.htm" />
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=yes">
<link rel="stylesheet" href="/themes/css/style-min-v1.css?v=3.1985">
<script src="/themes/js/script-min-v1.js"></script>
<script id="vi1" type="text/javascript" src="//services.bilsyndication.com/adv1/?q=0a8a90220201327770f6c986bea026a3" defer="" async=""></script>
<script id="vi2">
var vitag = vitag || {};
vitag.outStreamConfig = { enablePC:false, enableMobile:false};
vitag.smartBannerConfig = { enablePC: false, enableMobile: true, disableHorizontalPosition: "right left middle", disableVerticalPosition: "top middle" };
</script>
<script id="adp" data-cfasync="false" type="text/javascript">(function(w, d) { var s = d.createElement('script'); s.src = '//delivery.adrecover.com/18107/adRecover.js?ts=1572590509085'; s.type = 'text/javascript'; s.async = true; (d.getElementsByTagName('head')[0] || d.getElementsByTagName('body')[0]).appendChild(s); })(window, document);</script>
<script>function printPage() { window.print(); }</script>
<style>
.right-menu .mui-btn {
    background-color:#cc1e05;
}
a.demo {
    background:#cc1e05;
}
li.heading {
    background:#cc1e05;
}
.course-box{background:#cc1e05}
.home-intro-sub p{color:#cc1e05}
</style>
</head>
<body>
<header id="header">
<!-- Top sub-menu Starts Here -->
<div class="mui-appbar mui-container-fulid top-menu">
<div class="mui-container">
<div class="top-menu-item home">
<a href="https://www.tutorialspoint.com/index.htm" target="_blank" title="TutorialsPoint - Home"><i class="fal fa-home"></i> <span>Home</span></a>
</div>
<div class="top-menu-item qa">
<a href="https://www.tutorialspoint.com/about/about_careers.htm" target="_blank" title="Job @ Tutorials Point"><i class="fa fa-suitcase"></i> <span>Jobs</span></a>
</div>
<div class="top-menu-item tools">
<a href="https://www.tutorialspoint.com/online_dev_tools.htm" target="_blank" title="Tools - Online Development and Testing Tools"><i class="fal fa-cogs"></i> <span>Tools</span></a>
</div>
<div class="top-menu-item coding-ground">
<a href="https://www.tutorialspoint.com/codingground.htm" target="_blank" title="Coding Ground - Free Online IDE and Terminal"><i class="fal fa-code"></i> <span>Coding Ground </span></a> 
</div>
<div class="top-menu-item current-affairs">
<a href="https://www.tutorialspoint.com/current_affairs.htm" target="_blank" title="Daily Current Affairs"><i class="fal fa-layer-plus"></i> <span>Current Affairs</span></a>
</div>
<div class="top-menu-item upsc-notes">
<a href="https://www.tutorialspoint.com/upsc_ias_exams.htm" target="_blank" title="UPSC IAS Exams Notes - TutorialsPoint"><i class="fal fa-user-tie"></i> <span>UPSC Notes</span></a>
</div>      
<div class="top-menu-item online-tutoris">
<a href="https://www.tutorialspoint.com/tutor_connect/index.php" target="_blank" title="Top Online Tutors - Tutor Connect"><i class="fal fa-user"></i> <span>Online Tutors</span></a>
</div>
<div class="top-menu-item whiteboard">
<a href="https://www.tutorialspoint.com/whiteboard.htm" target="_blank" title="Free Online Whiteboard"><i class="fal fa-chalkboard"></i> <span>Whiteboard</span></a>
</div>
<div class="top-menu-item net-meeting">
<a href="https://www.tutorialspoint.com/netmeeting.php" target="_blank" title="A free tool for online video conferencing"><i class="fal fa-chalkboard-teacher"></i> <span>Net Meeting</span></a> 
</div>
<div class="top-menu-item articles">
<a href="https://www.tutorix.com" target="_blank" title="Tutorx - The Best Learning App" rel="nofollow"><i class="fal fa-video"></i> <span>Tutorix</span></a> 
</div>        
<div class="social-menu-item">
<a href="https://www.facebook.com/tutorialspointindia" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint @ Facebook"><i class="fab fa-facebook-f"></i></a> 
<a href="https://www.twitter.com/tutorialspoint" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint @ Twitter"><i class="fab fa-twitter"></i></a>
<a href="https://www.linkedin.com/company/tutorialspoint" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint @ Linkedin"><i class="fab fa-linkedin-in"></i></a>
<a href="https://www.youtube.com/channel/UCVLbzhxVTiTLiVKeGV7WEBg" target="_blank" rel="nofollow" data-placement="bottom" title="tutorialspoint YouTube"><i class="fab fa-youtube"></i></a>
</div>        
</div>
</div>
<!-- Top sub-menu Ends Here -->
<!-- Top main-menu Starts Here -->
<div class="mui-appbar mui-container-fulid mui--appbar-line-height mui--z1" id="logo-menu">
<div class="mui-container">
<div class="left-menu">
<a href="https://www.tutorialspoint.com/index.htm" title="Tutorialspoint">
<img class="tp-logo" alt="tutorialspoint" src="/scala/images/logo.png">
</a>
<div class="mui-dropdown">
<a class="mui-btn mui-btn--primary categories" data-mui-toggle="dropdown"><i class="fa fa-th-large"></i> 
<span>Categories <span class="mui-caret"></span></span></a>            
<ul class="mui-dropdown__menu cat-menu">
<li>
<ul>
<li><a href="/academic_tutorials.htm"><i class="fa fa-caret-right"></i> Academic Tutorials</a></li>
<li><a href="/big_data_tutorials.htm"><i class="fa fa-caret-right"></i> Big Data &amp; Analytics </a></li>
<li><a href="/computer_programming_tutorials.htm"><i class="fa fa-caret-right"></i> Computer Programming </a></li>
<li><a href="/computer_science_tutorials.htm"><i class="fa fa-caret-right"></i> Computer Science </a></li>
<li><a href="/database_tutorials.htm"><i class="fa fa-caret-right"></i> Databases </a></li>
<li><a href="/devops_tutorials.htm"><i class="fa fa-caret-right"></i> DevOps </a></li>
<li><a href="/digital_marketing_tutorials.htm"><i class="fa fa-caret-right"></i> Digital Marketing </a></li>
<li><a href="/engineering_tutorials.htm"><i class="fa fa-caret-right"></i> Engineering Tutorials </a></li>
<li><a href="/upsc_ias_exams.htm"><i class="fa fa-caret-right"></i> Exams Syllabus </a></li>
<li><a href="/famous_monuments.htm"><i class="fa fa-caret-right"></i> Famous Monuments </a></li>
<li><a href="/gate_exams_tutorials.htm"><i class="fa fa-caret-right"></i> GATE Exams Tutorials</a></li>
<li><a href="/latest_technologies.htm"><i class="fa fa-caret-right"></i> Latest Technologies </a></li>
<li><a href="/machine_learning_tutorials.htm"><i class="fa fa-caret-right"></i> Machine Learning </a></li>
<li><a href="/mainframe_tutorials.htm"><i class="fa fa-caret-right"></i> Mainframe Development </a></li>
<li><a href="/management_tutorials.htm"><i class="fa fa-caret-right"></i> Management Tutorials </a></li>
<li><a href="/maths_tutorials.htm"><i class="fa fa-caret-right"></i> Mathematics Tutorials</a></li>
<li><a href="/microsoft_technologies_tutorials.htm"><i class="fa fa-caret-right"></i> Microsoft Technologies </a></li>
<li><a href="/misc_tutorials.htm"><i class="fa fa-caret-right"></i> Misc tutorials </a></li>
<li><a href="/mobile_development_tutorials.htm"><i class="fa fa-caret-right"></i> Mobile Development </a></li>
<li><a href="/java_technology_tutorials.htm"><i class="fa fa-caret-right"></i> Java Technologies </a></li>
<li><a href="/python_technologies_tutorials.htm"><i class="fa fa-caret-right"></i> Python Technologies </a></li>
<li><a href="/sap_tutorials.htm"><i class="fa fa-caret-right"></i> SAP Tutorials </a></li>
<li><a href="/scripting_lnaguage_tutorials.htm"><i class="fa fa-caret-right"></i>Programming Scripts </a></li>
<li><a href="/selected_reading.htm"><i class="fa fa-caret-right"></i> Selected Reading </a></li>
<li><a href="/software_quality_tutorials.htm"><i class="fa fa-caret-right"></i> Software Quality </a></li>
<li><a href="/soft_skill_tutorials.htm"><i class="fa fa-caret-right"></i> Soft Skills </a></li>
<li><a href="/telecom_tutorials.htm"><i class="fa fa-caret-right"></i> Telecom Tutorials </a></li>
<li><a href="/upsc_ias_exams.htm"><i class="fa fa-caret-right"></i> UPSC IAS Exams </a></li>
<li><a href="/web_development_tutorials.htm"><i class="fa fa-caret-right"></i> Web Development </a></li>
<li><a href="/sports_tutorials.htm"><i class="fa fa-caret-right"></i> Sports Tutorials </a></li>
<li><a href="/xml_technologies_tutorials.htm"><i class="fa fa-caret-right"></i> XML Technologies </a></li>
<li><a href="/multi_language_tutorials.htm"><i class="fa fa-caret-right"></i> Multi-Language</a></li>
<li><a href="/questions_and_answers.htm"><i class="fa fa-caret-right"></i> Interview Questions</a></li>
</ul>
</li>
</ul>
<div class="clear"></div>
</div> 
</div>
<div class="right-menu">
<div class="toc-toggle">
<a href="javascript:void(0);"><i class="fa fa-bars"></i></a>
</div>

<div class="mobile-search-btn">
<a href="https://www.tutorialspoint.com/search.htm"><i class="fal fa-search"></i></a>
</div>
<div class="search-box">
<script async src="https://cse.google.com/cse.js?cx=013888361730801937261:17wrhjvne0b"></script>
<div class='gcse-search'></div>
</div>

<div class="menu-btn library-btn">
<a href="https://www.tutorialspoint.com/tutorialslibrary.htm"><i class="fal fa-cubes"></i> <span>Library</span></a>
</div>
<div class="menu-btn videos-btn">
<a href="https://www.tutorialspoint.com/videotutorials/index.php"><i class="fal fa-video"></i> <span>Videos</span></a> 
</div>
<div class="menu-btn videos-btn">
<a href="https://www.tutorialspoint.com/questions/index.php"><i class="fa fa-location-arrow"></i> <span>Q/A</span></a>
</div>
<div class="menu-btn ebooks-btn">
<a href="https://store.tutorialspoint.com"><i class="fal fa-book"></i> <span>eBooks</span></a>
</div>
<div class="mui-dropdown">
<button class="mui-btn mui-btn--primary mobile-menu" data-mui-toggle="dropdown">
<span class="mui-caret"></span>
</button>
<ul class="mui-dropdown__menu">
<li><a href="https://www.tutorialspoint.com/tutorialslibrary.htm"><i class="fal fa-cubes"></i> <span>Library</span></a></li>
<li><a href="https://www.tutorialspoint.com/videotutorials/index.php"><i class="fal fa-video"></i> <span>Videos</span></a></li>
<li><a href="https://store.tutorialspoint.com"><i class="fal fa-book"></i> <span>eBooks</span></a></li>
</ul>
</div>
</div>
</div>
</div>
<!-- Top main-menu Ends Here -->
</header>
<div class="mui-container-fluid content">
<div class="mui-container">
<!-- Tutorial ToC Starts Here -->
<div class="mui-col-md-3 tutorial-toc">
<div class="mini-logo">
<img src="/scala/images/scala-mini-logo.jpg" alt="Scala Tutorial" />
</div>
<ul class="toc chapters">
<li class="heading">Scala Tutorial</li>
<li><a href="/scala/index.htm">Scala - Home</a></li>
<li><a href="/scala/scala_overview.htm">Scala - Overview</a></li>
<li><a href="/scala/scala_environment_setup.htm">Scala - Environment Setup</a></li>
<li><a href="/scala/scala_basic_syntax.htm">Scala - Basic Syntax</a></li>
<li><a href="/scala/scala_data_types.htm">Scala - Data Types</a></li>
<li><a href="/scala/scala_variables.htm">Scala - Variables</a></li>
<li><a href="/scala/scala_classes_objects.htm">Scala - Classes &amp; Objects</a></li>
<li><a href="/scala/scala_access_modifiers.htm">Scala - Access Modifiers</a></li>
<li><a href="/scala/scala_operators.htm">Scala - Operators</a></li>
<li><a href="/scala/scala_if_else.htm">Scala - IF ELSE </a></li>
<li><a href="/scala/scala_loop_types.htm">Scala - Loop Statements</a></li>
<li><a href="/scala/scala_functions.htm">Scala - Functions</a></li>
<li><a href="/scala/scala_closures.htm">Scala - Closures</a></li>
<li><a href="/scala/scala_strings.htm">Scala - Strings</a></li>
<li><a href="/scala/scala_arrays.htm">Scala - Arrays</a></li>
<li><a href="/scala/scala_collections.htm">Scala - Collections</a></li>
<li><a href="/scala/scala_traits.htm">Scala - Traits</a></li>
<li><a href="/scala/scala_pattern_matching.htm">Scala - Pattern Matching</a></li>
<li><a href="/scala/scala_regular_expressions.htm">Scala - Regular Expressions</a></li>
<li><a href="/scala/scala_exception_handling.htm">Scala - Exception Handling</a></li>
<li><a href="/scala/scala_extractors.htm">Scala - Extractors</a></li>
<li><a href="/scala/scala_file_io.htm">Scala - Files I/O</a></li>
</ul>
<ul class="toc chapters">
<li class="heading">Scala Useful Resources</li>
<li><a href="/scala/scala_quick_guide.htm">Scala - Quick Guide</a></li>
<li><a href="/scala/scala_useful_resources.htm">Scala - Useful Resources</a></li>
<li><a href="/scala/scala_discussion.htm">Scala - Discussion</a></li>
</ul>
<ul class="toc reading">
<li class="sreading">Selected Reading</li>
<li><a target="_top" href="/upsc_ias_exams.htm">UPSC IAS Exams Notes</a></li>
<li><a target="_top" href="/developers_best_practices/index.htm">Developer's Best Practices</a></li>
<li><a target="_top" href="/questions_and_answers.htm">Questions and Answers</a></li>
<li><a target="_top" href="/effective_resume_writing.htm">Effective Resume Writing</a></li>
<li><a target="_top" href="/hr_interview_questions/index.htm">HR Interview Questions</a></li>
<li><a target="_top" href="/computer_glossary.htm">Computer Glossary</a></li>
<li><a target="_top" href="/computer_whoiswho.htm">Who is Who</a></li>
</ul>
<div id="stickyparent">
<div style="height:250px;width:300px;" id="sticky-ad">
<div class="adsbyvli" data-ad-slot="vi_9012177"></div><script>(vitag.Init = window.vitag.Init || []).push(function(){viAPItag.display("vi_9012177")})</script>
</div>
</div>
</div>
<!-- Tutorial ToC Ends Here -->
<!-- Tutorial Content Starts Here -->
<div class="mui-col-md-6 tutorial-content">
<h1>Scala - Overview</h1>
<hr />
<div id="google-top-ads">
<div class="top-ad-heading">Advertisements</div>
<div style="text-align:center" class="google-top-ads">
<div id="vi_top_ads" style="text-align:center !important;"></div>
   <script>
     (function() {
     var adPos = document.getElementById('vi_top_ads');
     var ad_id_728 = "vi_9012178";
     var ad_id_650 = "vi_9014435";
     var ad_id_300 = "vi_9017967";
     var width = window.innerWidth;
     var ad_id = ad_id_728;
     if( width <= 768 ){
        ad_id =  ad_id_300;
     }else if( width <= 1435 ){
        ad_id =  ad_id_650;
     }
     adPos.innerHTML = '<div class="adsbyvli" data-ad-slot="' + ad_id + '"></div>';
     (vitag.displayInit = window.vitag.displayInit || []).push(function () {
         viAPItag.display(ad_id);
     });
     }())
   </script>
</div>
</div>
<div class="mui-container-fluid button-borders">
<div class="pre-btn">
<a href="/scala/index.htm"><i class="fal fa-chevron-circle-left"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="/scala/scala_environment_setup.htm">Next Page <i class="fal fa-chevron-circle-right"></i>&nbsp;</a>
</div>
</div>
<div class="clearer"></div>
<p>Scala, short for Scalable Language, is a hybrid functional programming language. It was created by Martin Odersky. Scala smoothly integrates the features of object-oriented and functional languages. Scala is compiled to run on the Java Virtual Machine. Many existing companies, who depend on Java for business critical applications, are turning to Scala to boost their development productivity, applications scalability and overall reliability.</p>
<p>Here we have presented a few points that makes Scala the first choice of application developers.</p>
<h3>Scala is object-oriented</h3>
<p>Scala is a pure object-oriented language in the sense that every value is an object. Types and behavior of objects are described by classes and traits which will be explained in subsequent chapters.</p>
<p>Classes are extended by <b>subclassing</b> and a flexible <b>mixin-based composition</b> mechanism as a clean replacement for multiple inheritance.</p>
<h3>Scala is functional</h3>
<p>Scala is also a functional language in the sense that every function is a value and every value is an object so ultimately every function is an object.</p>
<p>Scala provides a lightweight syntax for defining <b>anonymous functions</b>, it supports <b>higher-order functions</b>, it allows functions to be <b>nested</b>, and supports <b>currying</b>. These concepts will be explained in subsequent chapters.</p>
<h3>Scala is statically typed</h3>
<p>Scala, unlike some of the other statically typed languages (C, Pascal, Rust, etc.), does not expect you to provide redundant type information. You don't have to specify a type in most cases, and you certainly don't have to repeat it.</p>
<h3>Scala runs on the JVM</h3>
<p>Scala is compiled into Java Byte Code which is executed by the Java Virtual Machine (JVM). This means that Scala and Java have a common runtime platform. You can easily move from Java to Scala.</p>
<p>The Scala compiler compiles your Scala code into Java Byte Code, which can then be executed by the '<b>scala</b>' command. The '<b>scala</b>' command is similar to the <b>java</b> command, in that it executes your compiled Scala code.</p>
<h3>Scala can Execute Java Code</h3>
<p>Scala enables you to use all the classes of the Java SDK and also your own custom Java classes, or your favorite Java open source projects.</p>
<h3>Scala can do Concurrent &amp; Synchronize processing</h3>
<p>Scala allows you to express general programming patterns in an effective way. It reduces the number of lines and helps the programmer to code in a type-safe way. It allows you to write codes in an immutable manner, which makes it easy to apply concurrency and parallelism (Synchronize).</p>
<h2>Scala vs Java</h2>
<p>Scala has a set of features that completely differ from Java. Some of these are &minus;</p>
<ul class="list">
<li>All types are objects</li>
<li>Type inference</li>
<li>Nested Functions</li>
<li>Functions are objects</li>
<li>Domain specific language (DSL) support</li>
<li>Traits</li>
<li>Closures</li>
<li>Concurrency support inspired by Erlang</li>
</ul>
<h2>Scala Web Frameworks</h2>
<p>Scala is being used everywhere and importantly in enterprise web applications. You can check a few of the most popular Scala web frameworks &minus;</p>
<ul class="list">
<li><p><a rel="nofollow" target="_blank" href="http://liftweb.net">The Lift Framework</a></p></li>
<li><p><a rel="nofollow" target="_blank" href="http://www.playframework.org/">The Play framework</a></p></li>
<li><p><a rel="nofollow" target="_blank" href="https://github.com/bowler-framework/bowler-quickstart">The Bowler framework</a></p></li>
</ul>
<div class="mui-container-fluid button-borders show">
<div class="pre-btn">
<a href="/scala/index.htm"><i class="fal fa-chevron-circle-left"></i> Previous Page</a>
</div>
<div class="nxt-btn">
<a href="/scala/scala_environment_setup.htm">Next Page <i class="fal fa-chevron-circle-right"></i>&nbsp;</a>
</div>
</div>
<div class="space-bottom" style="margin-bottom:15px;"></div>
<div class="google-bottom-ads" id="google-bottom-ads">
<div>Advertisements</div>
<div>
<div id="vi_bottom_ads"></div>
   <script>
     (function() {
     var adPos = document.getElementById('vi_bottom_ads');
     var mobile_ad_id = "vi_9017967";
     var desktop_ad_id = "vi_9013190";
     var ad_id = window.innerWidth <= 768 ? mobile_ad_id : desktop_ad_id;
     adPos.innerHTML = '<div class="adsbyvli" data-ad-slot="' + ad_id + '"></div>';
     (vitag.displayInit = window.vitag.displayInit || []).push(function () {
         viAPItag.display(ad_id);
     });
     }())
   </script>
</div>
<div class="space-bottom"></div>
</div>
</div>
<!-- Tutorial Content Ends Here -->
<!-- Right Column Starts Here -->
<style>
ul.paid-menu li{
    list-style: none;
    font-size: 16px;
    margin-left: -31px;
    padding: 8px;
    border-bottom: 1px solid #e6e6e6;
    color: #848383;
}
.google-right-ads>.mui-panel{
   margin-bottom: 15px;
}
.bottom-menu{
    position: absolute;
    bottom: 90px;
    left:15px;
    right: 0;
    text-align: center;
}
.bottom-menu button{
   width:120px;
}
.tutorial-content, .google-right-ads>.mui-panel {
    border-radius: 10px;
}
.mui--text-body2 {
    font-weight: 700;
    font-size: 14px;
    line-height: 24px;
}
.fa-sign-out-alt{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M160 217.1c0-8.8 7.2-16 16-16h144v-93.9c0-7.1 8.6-10.7 13.6-5.7l141.6 143.1c6.3 6.3 6.3 16.4 0 22.7L333.6 410.4c-5 5-13.6 1.5-13.6-5.7v-93.9H176c-8.8 0-16-7.2-16-16v-77.7m-32 0v77.7c0 26.5 21.5 48 48 48h112v61.9c0 35.5 43 53.5 68.2 28.3l141.7-143c18.8-18.8 18.8-49.2 0-68L356.2 78.9c-25.1-25.1-68.2-7.3-68.2 28.3v61.9H176c-26.5 0-48 21.6-48 48zM0 112v288c0 26.5 21.5 48 48 48h132c6.6 0 12-5.4 12-12v-8c0-6.6-5.4-12-12-12H48c-8.8 0-16-7.2-16-16V112c0-8.8 7.2-16 16-16h132c6.6 0 12-5.4 12-12v-8c0-6.6-5.4-12-12-12H48C21.5 64 0 85.5 0 112z"/></svg>') no-repeat;
 }
.fa-edit{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M417.8 315.5l20-20c3.8-3.8 10.2-1.1 10.2 4.2V464c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h292.3c5.3 0 8 6.5 4.2 10.2l-20 20c-1.1 1.1-2.7 1.8-4.2 1.8H48c-8.8 0-16 7.2-16 16v352c0 8.8 7.2 16 16 16h352c8.8 0 16-7.2 16-16V319.7c0-1.6.6-3.1 1.8-4.2zm145.9-191.2L251.2 436.8l-99.9 11.1c-13.4 1.5-24.7-9.8-23.2-23.2l11.1-99.9L451.7 12.3c16.4-16.4 43-16.4 59.4 0l52.6 52.6c16.4 16.4 16.4 43 0 59.4zm-93.6 48.4L403.4 106 169.8 339.5l-8.3 75.1 75.1-8.3 233.5-233.6zm71-85.2l-52.6-52.6c-3.8-3.8-10.2-4-14.1 0L426 83.3l66.7 66.7 48.4-48.4c3.9-3.8 3.9-10.2 0-14.1z"/></svg>') no-repeat;
 }
.fa-flag{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M344.348 74.667C287.742 74.667 242.446 40 172.522 40c-28.487 0-53.675 5.322-76.965 14.449C99.553 24.713 75.808-1.127 46.071.038 21.532.999 1.433 20.75.076 45.271-1.146 67.34 12.553 86.382 32 93.258V500c0 6.627 5.373 12 12 12h8c6.627 0 12-5.373 12-12V378.398c31.423-14.539 72.066-29.064 135.652-29.064 56.606 0 101.902 34.667 171.826 34.667 51.31 0 91.933-17.238 130.008-42.953 6.589-4.45 10.514-11.909 10.514-19.86V59.521c0-17.549-18.206-29.152-34.122-21.76-36.78 17.084-86.263 36.906-133.53 36.906zM48 28c11.028 0 20 8.972 20 20s-8.972 20-20 20-20-8.972-20-20 8.972-20 20-20zm432 289.333C456.883 334.03 415.452 352 371.478 352c-63.615 0-108.247-34.667-171.826-34.667-46.016 0-102.279 10.186-135.652 26V106.667C87.117 89.971 128.548 72 172.522 72c63.615 0 108.247 34.667 171.826 34.667 45.92 0 102.217-18.813 135.652-34.667v245.333z"/></svg>') no-repeat;
 }
.fa-bug{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><path d="M544 272h-64V150.627l35.313-35.313c6.249-6.248 6.249-16.379 0-22.627-6.248-6.248-16.379-6.248-22.627 0L457.373 128H417C417 57.26 359.751 0 289 0c-70.74 0-128 57.249-128 128h-42.373L75.314 84.687c-6.249-6.248-16.379-6.248-22.628 0-6.248 6.248-6.248 16.379 0 22.627L96 150.627V272H32c-8.836 0-16 7.163-16 16s7.164 16 16 16h64v24c0 36.634 11.256 70.686 30.484 98.889l-57.797 57.797c-6.249 6.248-6.249 16.379 0 22.627 6.249 6.249 16.379 6.248 22.627 0l55.616-55.616C178.851 483.971 223.128 504 272 504h32c48.872 0 93.149-20.029 125.071-52.302l55.616 55.616c6.249 6.249 16.379 6.248 22.627 0 6.249-6.248 6.249-16.379 0-22.627l-57.797-57.797C468.744 398.686 480 364.634 480 328v-24h64c8.837 0 16-7.163 16-16s-7.163-16-16-16zM289 32c53.019 0 96 42.981 96 96H193c0-53.019 42.981-96 96-96zm15 440V236c0-6.627-5.373-12-12-12h-8c-6.627 0-12 5.373-12 12v236c-79.402 0-144-64.599-144-144V160h320v168c0 79.401-64.599 144-144 144z"/></svg>') no-repeat;
 }
.fa-bell{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M433.884 366.059C411.634 343.809 384 316.118 384 208c0-79.394-57.831-145.269-133.663-157.83A31.845 31.845 0 0 0 256 32c0-17.673-14.327-32-32-32s-32 14.327-32 32c0 6.75 2.095 13.008 5.663 18.17C121.831 62.731 64 128.606 64 208c0 108.118-27.643 135.809-49.893 158.059C-16.042 396.208 5.325 448 48.048 448H160c0 35.29 28.71 64 64 64s64-28.71 64-64h111.943c42.638 0 64.151-51.731 33.941-81.941zM224 480c-17.645 0-32-14.355-32-32h64c0 17.645-14.355 32-32 32zm175.943-64H48.048c-14.223 0-21.331-17.296-11.314-27.314C71.585 353.836 96 314.825 96 208c0-70.741 57.249-128 128-128 70.74 0 128 57.249 128 128 0 106.419 24.206 145.635 59.257 180.686C421.314 398.744 414.11 416 399.943 416z"/></svg>') no-repeat;
 }
.fa-badge-check{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M512 256c0-35.496-19.411-68.153-49.598-85.502 9.075-33.611-.289-70.424-25.383-95.517-25.092-25.094-61.902-34.458-95.518-25.384C324.153 19.411 291.496 0 256 0s-68.153 19.411-85.502 49.598c-33.612-9.076-70.425.291-95.518 25.384-25.094 25.093-34.458 61.905-25.383 95.517C19.411 187.847 0 220.504 0 256s19.411 68.153 49.598 85.502c-9.075 33.611.289 70.424 25.383 95.519 26.511 26.507 63.455 34.154 95.532 25.406C187.865 492.6 220.514 512 256 512s68.135-19.4 85.487-49.573c32.709 8.92 69.471.651 95.532-25.407 25.094-25.094 34.458-61.906 25.383-95.518C492.589 324.153 512 291.496 512 256zm-91.145 68.29c5.346 11.778 29.582 54.057-6.463 90.102-28.863 28.861-57.547 21.24-90.103 6.464C319.745 432.959 306.99 480 256 480c-52.106 0-64.681-49.533-68.29-59.145-32.611 14.801-61.35 22.286-90.103-6.463-36.746-36.747-10.826-80.49-6.463-90.103C79.042 319.745 32 306.99 32 256c0-52.106 49.533-64.681 59.145-68.29-5.346-11.778-29.582-54.057 6.463-90.102 36.836-36.833 80.756-10.706 90.103-6.464C192.255 79.041 205.01 32 256 32c52.106 0 64.681 49.533 68.29 59.145 11.769-5.342 54.059-29.58 90.103 6.464 36.746 36.745 10.826 80.489 6.463 90.102C432.958 192.255 480 205.01 480 256c0 52.106-49.533 64.681-59.145 68.29zm-32.404-138.802L207.971 364.52c-4.705 4.667-12.303 4.637-16.97-.068l-85.878-86.572c-4.667-4.705-4.637-12.303.068-16.97l8.52-8.451c4.705-4.667 12.303-4.637 16.971.068l68.976 69.533 163.441-162.129c4.705-4.667 12.303-4.637 16.97.068l8.452 8.52c4.666 4.703 4.635 12.301-.07 16.969z"/></svg>') no-repeat;
 }
.fa-box-up{
 background: url('data:image/svg+xml;utf8, <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M408 384H104c-4.4 0-8 3.6-8 8v16c0 4.4 3.6 8 8 8h304c4.4 0 8-3.6 8-8v-16c0-4.4-3.6-8-8-8zM448 0H64C28.7 0 0 28.7 0 64v384c0 35.3 28.7 64 64 64h384c35.3 0 64-28.7 64-64V64c0-35.3-28.7-64-64-64zm32 448c0 17.6-14.4 32-32 32H64c-17.6 0-32-14.4-32-32V64c0-17.6 14.4-32 32-32h384c17.6 0 32 14.4 32 32v384zM108.5 202l35.5-44.4V312c0 4.4 3.6 8 8 8h16c4.4 0 8-3.6 8-8V157.6l35.5 44.4c4.6 5.8 14.5 8.8 22.5 2.5 6.9-5.5 8-15.6 2.5-22.5l-64-80c-6.1-7.6-18.9-7.6-25 0l-64 80c-5.5 6.9-4.4 17 2.5 22.5s17 4.4 22.5-2.5zm256-100c-6.1-7.6-18.9-7.6-25 0l-64 80c-5.5 6.9-4.4 17 2.5 22.5s17 4.4 22.5-2.5l35.5-44.4V312c0 4.4 3.6 8 8 8h16c4.4 0 8-3.6 8-8V157.6l35.5 44.4c4.6 5.8 14.5 8.8 22.5 2.5 6.9-5.5 8-15.6 2.5-22.5l-64-80z"/></svg>') no-repeat;
 }

</style>
<div class="mui-col-md-2 google-right-ads" style="padding-right:0px;text-align: left;">
<div class="space-top"></div>
<div class="mui-panel" style="height:540px;box-shadow:none; -webkit-box-shadow:none;">
<ul class="paid-menu">
<li><i class="fa fa-print"></i>&nbsp;Print</li>
<li><i class="fal fa-edit"></i>&nbsp;Notes</li>
<li><i class="fal fa-bookmark"></i>&nbsp;Bookmark</li>
<li><i class="fal fa-bell"></i>&nbsp;Report Error</li>
<li><i class="fal fa-badge-check"></i>&nbsp;Suggestions</li>
</ul>
<div class="bottom-menu">
<button class="tp-btn"><i class="fal fa-box-up"></i> <a href="">Dashboard</a></button>
<button class="tp-btn"><i class="fal fa-sign-out-alt"></i> <a href="">Logout</a></button>
</div>
</div>
</div>
<!-- Right Column Ends Here -->
</div>
</div>
<div class="clear"></div>
<footer id="footer">
<div class="mui--text-center">
<div class="mui--text-caption mui--text-light">
<a href="/index.htm" class="logo"><img class="img-responsive" src="/images/logo-black.png" alt="Tutorials Point" title="Tutorials Point"></a>
</div>
<ul class="mui-list--inline mui--text-body2 mui--text-light">
<li><a href="/about/index.htm"><i class="fal fa-globe"></i> About us</a></li>
<li><a href="/about/about_terms_of_use.htm"><i class="fal fa-asterisk"></i> Terms of use</a></li>
<li><a href="/about/about_privacy.htm"> <i class="fal fa-shield-check"></i> Privacy Policy</a></li>
<li><a href="/about/faq.htm"><i class="fal fa-question-circle"></i> FAQ's</a></li>
<li><a href="/about/about_helping.htm"><i class="fal fa-hands-helping"></i> Helping</a></li>
<li><a href="/about/contact_us.htm"><i class="fal fa-map-marker-alt"></i> Contact</a></li>
</ul>
<div class="mui--text-caption mui--text-light bottom-copyright-text">&copy; Copyright 2019. All Rights Reserved.</div>
</div>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-232293-17"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'UA-232293-6');

// Check if cookie is set for subscribed user then do the following
var elem = document. getElementById("vi1"); 
elem.parentNode.removeChild(elem);
var elem = document. getElementById("vi2"); 
elem.parentNode.removeChild(elem);
var elem = document. getElementById("adp"); 
elem.parentNode.removeChild(elem);
var elem = document. getElementById("stickyparent"); 
elem.parentNode.removeChild(elem);
var elem =  document. getElementsByTagName("hr")[0];
elem.parentNode.removeChild(elem);
var elem = document. getElementById("google-top-ads"); 
elem.parentNode.removeChild(elem);
var elem = document. getElementById("google-bottom-ads"); 
elem.parentNode.removeChild(elem);

</script>
</footer>
</body>
</html>
